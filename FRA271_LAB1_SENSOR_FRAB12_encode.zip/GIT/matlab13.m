% plot(CWCCW.Time, CWCCW.Data);
% grid on;
% grid minor;
% xlabel('Time (s)');
% ylabel('Counts');
% title('Encoder X2 Response');











clear a
a = 4; 
y = lebron_jame;
x = lebron_jame;
 % หาค่าบวกหรือลบที่มากที่สุด

% ดึงสัญญาณออกมาจาก Dataset
sig_1   = x.getElement(4);
sig_2 = y.getElement(7);

% พล็อตกราฟ
figure('Color', 'w');


% 
% subplot(1, 2, 1); % เลือกช่องที่ 1 (แถวที่ 1, คอลัมน์ที่ 1)
plot(sig_1.Values.Time, sig_1.Values.Data, 'r-', 'LineWidth', 2, 'DisplayName', 'Degree');
grid on; 
grid minor;
xlabel('Time (s)' ,'FontSize',16,FontWeight='bold',Color="black"); 
ylabel('Value'    ,'FontSize',16,FontWeight='bold',Color="black");
legend('Location', 'best');

set(gca, 'Color', 'w');              % สีพื้นหลังด้านในของตารางเป็นสีขาว
set(gca, 'XColor', 'k', 'YColor', 'k'); % สีตัวเลขอิงแกน X และ Y เป็นสีดำ
set(gca, 'GridColor', [0.5 0.5 0.5]); % สีเส้นตาราง (Grid) ให้มองเห็นชัดบนพื้นขาว


title("Raw signal VS Degree in one Revolue (X" + a + ")", 'FontSize', 20, 'FontWeight', 'bold','Color','black');
ylim([-390 390]);
yticks(-390:45:390);
% ylim([-70 70]);
% yticks(-70:15:70);

hold on;
plot(sig_2.Values.Time, sig_2.Values.Data, 'b-', 'LineWidth', 2, 'DisplayName', 'Degree');

% subplot(1, 2, 2); 
% plot(sig_2.Values.Time, sig_2.Values.Data, 'b-', 'LineWidth', 2, 'DisplayName', 'Degree');
% 
% 
% grid on; 
% grid minor;
% xlabel('Time (s)' ,'FontSize',16,FontWeight='bold',Color="black"); 
% ylabel('Value'    ,'FontSize',16,FontWeight='bold',Color="black");
% legend('Location', 'best');
%  % ตัวเลขที่ต้องการเปลี่ยน (เช่น 1, 2, 4)
% 
%  set(gca, 'Color', 'w');              % สีพื้นหลังด้านในของตารางเป็นสีขาว
%  set(gca, 'XColor', 'k', 'YColor', 'k'); % สีตัวเลขอิงแกน X และ Y เป็นสีดำ
%  set(gca, 'GridColor', [0.5 0.5 0.5]); % สีเส้นตาราง (Grid) ให้มองเห็นชัดบนพื้นขาว
% 
% title("Un Warping Function (X" + a + ")", 'FontSize', 20, 'FontWeight', 'bold','Color','black');
% % ylim([-7 7]);
% % yticks(-7:0.5:7);
% ylim([-390 390]);
% yticks(-390:45:390);


% plot(t, x, 'LineWidth', 1.5);
% title(['Forced Duffing Oscillator Response (', num2str(b), ', ', num2str(a),")"]);
% xlabel('Time (s)');
% ylabel('Displacement (x)');
% grid on;                                                                                                  
% grid minor;



















% % เส้นสีแดง: จำนวนนับ (Counts)
% plot(sig_count.Values.Time, sig_count.Values.Data, 'r-', 'LineWidth', 1.5, ...
%     'DisplayName', 'Counts (Data Type Conversion)');
% hold off;
% 
% grid on;
% grid minor;
% xlabel('Time (s)');
% ylabel('Value');
% title('Encoder X2 Response (CW & CCW)');
% legend('Location', 'best');

% 1. ดึงสัญญาณ Data Type Conversion ออกมาจาก Dataset
% sig_conv = Run10.getElement('Data Type Conversion1:1');

% 2. พล็อตกราฟจาก .Values
% figure('Color', 'w');

% grid on;
% grid minor;
% % xlabel('Time (s)');
% % ylabel('Counts (int16)');
% title('Data Type Conversion Response');

